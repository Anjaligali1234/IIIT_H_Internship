// Table.js
// import React from 'react';
// import './Table.css';

// const Table = () => {
//     return (
//         <div className="table-container">
//             <h1 className="table-title">Table Page</h1>
//             <table className="table">
//                 <thead>
//                     <tr>
//                         <th>Name</th>
//                         <th>Day</th>
//                         <th>Genre</th>
//                         <th>Interest Level</th>
//                         <th>Year</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     <tr>
//                         <td>Rayudu</td>
//                         <td>sunday</td>
//                         <td>Pop</td>
//                         <td>Vibe</td>
//                         <td>1900-2000,2000-2010</td>
//                     </tr>
//                     <tr>
//                         <td>Mike</td>
//                         <td>Saturday</td>
//                         <td>Rock</td>
//                         <td>Vibe</td>
//                         <td>2000-2010</td>
//                     </tr>
//                     <tr>
//                         <td>Parumall</td>
//                         <td>saturnday</td>
//                         <td>Hip-hop</td>
//                         <td>Vibe</td>
//                         <td>2000-2010</td>
//                     </tr>
//                     <tr>
//                         <td>wade</td>
//                         <td>sunday</td>
//                         <td>classical</td>
//                         <td>Focus</td>
//                         <td>1900-2000</td>
//                     </tr>
//                 </tbody>
//             </table>
//         </div>
//     );
// };

// export default Table;

import React from 'react';
import './Table.css';

const Table = () => {
  const trainData = [
    {
      PNRNumber: '6237634724',
      trainNumber: '12345',
      trainName: 'Express 1',
      confirmationStatus: 'Confirmed',
      chartPreparationStatus: 'Chart Prepared',
    },
    {
      PNRNumber: '4567634224',
      trainNumber: '67890',
      trainName: 'Superfast 2',
      confirmationStatus: 'RAC',
      chartPreparationStatus: 'Chart Not Prepared',
    },
    {
        PNRNumber: '5427634224',
        trainNumber: '46802',
        trainName: 'Antyodaya',
        confirmationStatus: 'Confirmed',
        chartPreparationStatus: 'Chart Prepared',
    },
    {
        PNRNumber: '6527634224',
        trainNumber: '13579',
        trainName: 'Rajdhani 3',
        confirmationStatus: 'Confirmed',
        chartPreparationStatus: 'Chart Prepared',
    },
    {   
        PNRNumber: '6457634224',
        trainNumber: '97531',
        trainName: 'Shatabdi 5',
        confirmationStatus: 'not Confirmed',
        chartPreparationStatus: 'Chart Prepared',
    },

    {
        PNRNumber: '6543634224',
        trainNumber: '20846',
        trainName: 'Vande Bharat',
        confirmationStatus: 'RAC',
        chartPreparationStatus: 'Chart Prepared',
    },

    {
        PNRNumber: '6527634224',
        trainNumber: '12345',
        trainName: 'Garib Rath',
        confirmationStatus: 'RAC',
        chartPreparationStatus: 'Chart Prepared',
    },
    {
      PNRNumber: '6237634724',
      trainNumber: '12345',
      trainName: 'Express 1',
      confirmationStatus: 'Confirmed',
      chartPreparationStatus: 'Chart Prepared',
    },
    // Add more train data as needed
  ];

  const renderTableHeader = () => {
    return (

      <tr>
        <th>Train Number</th>
        <th>Train Name</th>
        <th>Confirmation Status</th>
        <th>Chart Preparation Status</th>
      </tr>
    );
  };

  const renderTableData = () => {
    return trainData.map((train) => (
      <tr key={train.trainNumber}>
        <td>{train.trainNumber}</td>
        <td>{train.trainName}</td>
        <td>{train.confirmationStatus}</td>
        <td>{train.chartPreparationStatus}</td>
      </tr>
    ));
  };

  return (

   
  
    <div className="table-container">
<h1>Ticket Booking Status</h1>
    
      <table>

        <thead>{renderTableHeader()}</thead>
        <tbody>{renderTableData()}</tbody>
      </table>
      <p>As you may have heard these terms while traveling on Indian Railways, “Charting”, “Chart Prepared” or “Chart Not Prepared”.

</p>
<h1>General Rules for Chart Preparation
</h1>
<p>* The first chart for any train is prepared by the authorities about 4 hours before the scheduled departure time of the train from the originating station.<br/>
* For the trains which are scheduled to depart early in the morning, the chart is prepared usually the night before the departure.<br/>
* If there are vacant seats remaining in the first chart which is prepared 4 hours before the departure, then the remaining seats are made available for booking.<br/>
* The final chart is prepared about 30 minutes before the departure of the train from the station.<br/>
* In the final chart, some of the waiting list tickets are confirmed.<br/>
* Passengers are assigned Berth and Coach Number in the final chart according to their status, either confirmed or RAC.<br/>
* E-Tickets which are on Fully Waiting List are canceled automatically</p>
  {/* <div className="card1">
        
   <h1>Bharat Gaurav Tourist Train</h1>    
    <p>
IRCTC operates Bharat Gaurav Tourist Train having AC III-Tier accommodation on train specially designed to promote domestic tourism in India. 
</p>
</div> */}

     
    </div>
  );
};

export default Table;
