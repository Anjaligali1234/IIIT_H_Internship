// import React, { useState } from 'react';
// import './Form.css';

// const Form = () => {
//   const [selectedDate, setSelectedDate] = useState('');
//   const [selectedDay, setSelectedDay] = useState('');
//   const [selectedGenre, setSelectedGenre] = useState('');
//   const [checkedGenres, setCheckedGenres] = useState([]);
//   const [selectedRadio, setSelectedRadio] = useState('');
//   const [inputText1, setInputText1] = useState('');
//   const [inputText2, setInputText2] = useState('');

//   const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
//   const genres = ['1900-2000', '2000-2010', '2010-2015', '2015-2020'];
//   const radioOptions = ['Vibe', 'Focus'];

//   const handleCheckboxChange = (genre) => {
//     const updatedGenres = [...checkedGenres];
//     if (updatedGenres.includes(genre)) {
//       updatedGenres.splice(updatedGenres.indexOf(genre), 1);
//     } else {
//       updatedGenres.push(genre);
//     }
//     setCheckedGenres(updatedGenres);
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     // Perform any actions with form data here
//     console.log({
//       selectedDate,
//       selectedDay,
//       selectedGenre,
//       checkedGenres,
//       selectedRadio,
//       inputText1,
//       inputText2,
//     });
//   };

//   return (
//     <div className="form-container">
//       <form onSubmit={handleSubmit}>
//         <label>
//           Date:
//           <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
//         </label>
//         <br />

//         <label>
//           Day:
//           <select value={selectedDay} onChange={(e) => setSelectedDay(e.target.value)}>
//             <option value="">Select a day</option>
//             {daysOfWeek.map((day) => (
//               <option key={day} value={day}>
//                 {day}
//               </option>
//             ))}
//           </select>
//         </label>
//         <br />

//         <label>
//           Genre:
//           <select value={selectedGenre} onChange={(e) => setSelectedGenre(e.target.value)}>
//             <option value="">Select a genre</option>
//             {genres.map((genre) => (
//               <option key={genre} value={genre}>
//                 {genre}
//               </option>
//             ))}
//           </select>
//         </label>
//         <br />

//         <label>
//           Year:
//           <div>
//             {genres.map((genre) => (
//               <label key={genre} className="checkbox-label">
//                 <input
//                   type="checkbox"
//                   value={genre}
//                   checked={checkedGenres.includes(genre)}
//                   onChange={() => handleCheckboxChange(genre)}
//                 />
//                 {genre}
//               </label>
//             ))}
//           </div>
//         </label>
//         <br />

//         <label>
//           Radio Options:
//           <div>
//             {radioOptions.map((option) => (
//               <label key={option} className="radio-label">
//                 <input
//                   type="radio"
//                   value={option}
//                   checked={selectedRadio === option}
//                   onChange={() => setSelectedRadio(option)}
//                 />
//                 {option}
//               </label>
//             ))}
//           </div>
//         </label>
//         <br />

//         <label>
//           Feed back :
//           <input type="text" value={inputText1} onChange={(e) => setInputText1(e.target.value)} />
//         </label>
//         <br />

//         <label>
//           comment   :
//           <input type="text" value={inputText2} onChange={(e) => setInputText2(e.target.value)} />
//         </label>
//         <br />

//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// };

// export default Form;
   
import React, { useState } from "react";
import "./Form.css";

const TrainBookingForm = () => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const [checkboxes, setCheckboxes] = useState({
    Lower: false,
    Upper: false,
    Middle: false,
    Sider: false,
  });
  const [paymentMethod, setPaymentMethod] = useState("");
  const [cardDetails, setCardDetails] = useState({
    cardNumber: "",
    cvv: "",
    expDate: "",
  });

  const handleCheckboxChange = (checkbox) => {
    setCheckboxes((prevCheckboxes) => ({
      ...prevCheckboxes,
      [checkbox]: !prevCheckboxes[checkbox],
    }));
  };

  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method);
  };

  const handleCardDetailsChange = (field, value) => {
    setCardDetails((prevCardDetails) => ({
      ...prevCardDetails,
      [field]: value,
    }));
  };

  const handleSearch = () => {
    // Add logic for searching trains
    console.log("Search button clicked!");
  };

  return (
    <div className="train-booking-container">
     {/* <header className="App-header">
        <h1>Train Ticket Booking </h1>
      </header> */}
      <form className="train-booking-form">
        <label htmlFor="from">From:</label>
        <input
          type="text"
          id="from"
          value={from}
          onChange={(e) => setFrom(e.target.value)}
        />

        <label htmlFor="to">To:</label>
        <input
          type="text"
          id="to"
          value={to}
          onChange={(e) => setTo(e.target.value)}
        />

        <label htmlFor="date">Date:</label>
        <input
          type="date"
          id="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />

        <label htmlFor="class">Select:</label>
        <select
          id="class"
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
        >
          <option value="all">All Classes</option>
          <option value="EA">Executive Class</option>
          <option value="1A">1st AC</option>
          <option value="2A">2nd AC</option>
          <option value="SL">Sleeper Class</option>
          <option value="EV">visadom AC</option>
          <option value="3A">AC 3 Tier</option>
        </select>

        <div className="checkbox-group">
          <label>Additional Options:</label>
          {Object.entries(checkboxes).map(([key, value]) => (
            <div key={key}>
              <input
                type="checkbox"
                id={key}
                checked={value}
                onChange={() => handleCheckboxChange(key)}
              />
              <label htmlFor={key}>{key}</label>
            </div>
          ))}
        </div>

        <div className="radio-group">
          <label>Select Payment Method:</label>
          <div>

            <label className="label1" htmlFor="CreditCard">Credit Card</label>
            <input
            className="r1"
              type="radio"
              id="creditCard"
              name="paymentMethod"
              value="creditCard"
              checked={paymentMethod === "creditCard"}
              onChange={() => handlePaymentMethodChange("creditCard")}
            />
          </div>
          <div>
           
          </div>
          <label className="label2" htmlFor="upi">UPI</label>
          <input 
          className="r2"
            type="radio"
            id="upi"
            name="paymentMethod"
            value="upi"
            checked={paymentMethod === "upi"}
            onChange={() => handlePaymentMethodChange("upi")}
          />
        </div>

        {paymentMethod === "creditCard" && (
          <div className="credit-card-details">
            <label htmlFor="cardNumber">Card Number:</label>
            <input
              type="text"
              id="cardNumber"
              value={cardDetails.cardNumber}
              onChange={(e) =>
                handleCardDetailsChange("cardNumber", e.target.value)
              }
            />

            <label htmlFor="cvv">CVV:</label>
            <input
              type="text"
              id="cvv"
              value={cardDetails.cvv}
              onChange={(e) => handleCardDetailsChange("cvv", e.target.value)}
            />

            <label htmlFor="expDate">Expiration Date:</label>
            <input
              type="text"
              id="expDate"
              value={cardDetails.expDate}
              onChange={(e) =>
                handleCardDetailsChange("expDate", e.target.value)
              }
            />
          </div>
        )}

        <button class="button" type="button" onClick={handleSearch}>
          Search
        </button>
        <button class="button1" type="button" onClick={handleSearch}>
          Try Ticket Booking
        </button>
      </form>
      {/* <footer>
        Book your online ticket by using form
      </footer> */}
    </div>
  );
};

export default TrainBookingForm;
