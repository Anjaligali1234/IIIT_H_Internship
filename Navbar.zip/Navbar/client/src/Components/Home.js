  import React from 'react';
  import './Home.css';

  function Home() {
    return (
      <div>
        <header className="header">
        <img className="irctc" src="https://res.cloudinary.com/djiiwzck9/image/upload/v1699868992/irctc_jsjrq7.png"/>
          <nav>

            <div className="logo">IRCTC Ticket Booking</div>
            <div className="search-bar">
              <input type="text" placeholder="PNR Status" />
                      <img src="https://res.cloudinary.com/djiiwzck9/image/upload/v1699865667/search_ufhrrf.png"  class="search-icon" />
              <i className="fas fa-search"></i>
            </div>
          </nav>
        </header>
        {/* <body className="main-body">
          {/* Your main content goes here 
        </body> */}
        <footer className="footer">
        <p>@Book your Ticket for your journey. </p>
      </footer>
      </div>
    );
  }

  export default Home;
