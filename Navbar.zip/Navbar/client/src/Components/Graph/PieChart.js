// PieCharts.js
import React from 'react';
import "./PieChart.css";
import { PieChart, Pie, Cell, Legend, Tooltip } from 'recharts';

const data = {
  // ... your data here
  IndianRail: [
    { name: 'Passangers', value: 45 },
    { name: 'Taxes', value: 20 },
    { name: 'Merchants', value: 15 },
    { name: 'Other', value: 20 },
  ],
  BulletTrain: [
    { name: 'Passangers', value: 30 },
    { name: 'Taxes', value: 15 },
    { name: 'Merchants', value: 10 },
    { name: 'Other', value: 45 },
  ],
 MetroTrain: [
    { name: 'Passangers', value: 20 },
    { name: 'Taxes', value: 25 },
    { name: 'Merchants', value: 30 },
    { name: 'Other', value: 25 },
  ],
  DarjeelingHimalayan: [
    { name: 'Passangers', value: 15 },
    { name: 'Taxes', value: 30 },
    { name: 'Merchants', value: 25 },
    { name: 'Other', value: 30 },
  ],
  RackRailway: [
    { name: 'Passangers', value: 45 },
    { name: 'Taxes', value: 20 },
    { name: 'Merchants', value: 15 },
    { name: 'Other', value: 20 },
  ],
  DoubleDeckerRail: [
    { name: 'Passangers', value: 45 },
    { name: 'Taxes', value: 20 },
    { name: 'Merchants', value: 15 },
    { name: 'Other', value: 20 },
  ],
  Locomotive: [
    { name: 'Passangers', value: 45 },
    { name: 'Taxes', value: 20 },
    { name: 'Merchants', value: 15 },
    { name: 'Other', value: 20 },
  ],
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const PieChartComponent = ({ chartData, title }) => {
  return (
    
    <div className="PieChartComponent">
      
      <h3 className="PieChartTitle">{title}</h3>
      <PieChart width={300} height={300}>
        <Pie
          data={chartData}
          dataKey="value"
          cx={150}
          cy={150}
          outerRadius={80}
          fill="#8884d8"
          label
        >
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip />
        <Legend align="center" verticalAlign="bottom" />
      </PieChart>
    </div>
  );
};

const PieCharts = () => {
  return (
  
    
    <div className="PieCharts">
      {Object.entries(data).map(([genre, chartData]) => (
        <PieChartComponent key={genre} chartData={chartData} title={genre} />
      ))}
    </div>
  );
};

export default PieCharts;


